package com.example.oauthtwo.model;

public enum  AuthProvider {
    local,
    facebook,
    google,
    github
}